# Telegram Auto-Reaction Bot (Hybrid)
This Railway-hosted Python bot fetches Telegram auto-reaction logic from a remote PHP server and runs it dynamically.

## Setup
1. Host your userbot Python code in a `mybot.php` on shared hosting.
2. Replace `PHP_URL` in `main.py` with your secure URL.
3. Push this repo to GitHub.
4. Deploy it on [Railway](https://railway.app) via GitHub.
